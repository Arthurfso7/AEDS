﻿using System;

class Program {
    static void Main() {

        
        int resp = 0; 

        int m = 0, n = 0;
        string linha;
        string[] valores;

        linha = Console.ReadLine();
        valores = linha.Split(' ');
        m = int.Parse(valores[0]);
        n = int.Parse(valores[1]);
       if(m==n)
       {
        int[,] matriz = new int[m, n];

        for (int i = 0; i < m; i++) {
            linha = Console.ReadLine();
            valores = linha.Split(' ');

            for (int j = 0; j < n; j++) {
                matriz[i, j] = int.Parse(valores[j]);
            }
        }


        for (int i = 0; i < m; i++) {

            for (int j = 0; j < n; j++) {

                if (matriz[i, j] != matriz[j, i]) {
                    resp = 0;

                    i=m; 
                   
                }
            }
                
        resp = 1;
        
        }
        Console.WriteLine(resp);
       }
       else{

        Console.WriteLine(resp);
        
       }

    }
}

