﻿using System;

class Program
{
    static void Main()
    {
        int resp;
        int indice, Numbase, Numexpoente;
        string linha;
        string[] valores;

        linha = Console.ReadLine();
        valores = linha.Split(' ');
        indice = int.Parse(valores[0]);

        for (int i = 0; i < indice; i++)
        {
            linha = Console.ReadLine();
            valores = linha.Split(' ');
            Numbase = int.Parse(valores[0]);
            Numexpoente = int.Parse(valores[1]);

            resp = 1; 

            for (int j = 1; j <= Numexpoente; j++)
            {
                resp *= Numbase;
            }
            Console.WriteLine(resp);
        }
    }
}

















