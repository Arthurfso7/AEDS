﻿using System;
class Program{
static void Main(string []args)
{

int num;
num = int.Parse(Console.ReadLine());

while(num > 0)
{
 if (num % 2 == 0)
 Console.WriteLine("PAR");
else 
Console.WriteLine("IMPAR");
num = int.Parse(Console.ReadLine());

}

}

}
