﻿using System;

class Program{

public static void Main(string[]args)
{

string c = Console.ReadLine();
int r ;
while(c != "FIM")
{
    r = b(c);
    Console.WriteLine(r);
    c = Console.ReadLine();
    
    }

}

    public static int b(string c)
    {
        int cont = 0;
        for (int i = 0; i < c.Length; i++)
        {
            if (c[i] >= 'A' && c[i] <= 'Z')
            {

                cont++;

            }

        }

        return cont;
    }

}