﻿using System;
class Program{
static void Main(){
int id_M= 0, id_A= 0, id_B, id_C =0, resp =0;
id_M= int.Parse(Console.ReadLine());
id_A= int.Parse(Console.ReadLine());
id_B= int.Parse(Console.ReadLine());

id_C = (id_M - id_A - id_B);  

if(id_A>id_B && id_A>id_C){
resp = id_A;
}
else if(id_B>id_A && id_B> id_C){
resp = id_B;
}
else if(id_C>id_A && id_C>id_B){
resp = id_C;
}
Console.WriteLine(resp);
}
}



