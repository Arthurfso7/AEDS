﻿using System;
class Program{
static void Main(){
int x= 0, n =0, m_i = 0, resp =0, soma= 0;

;
while(x<1 || x>100){
x = int.Parse(Console.ReadLine());
}
while(n<1 || n>100){
n = int.Parse(Console.ReadLine());
}
for(int i = 0; i<n; i++){
    m_i = int.Parse(Console.ReadLine());
    if(m_i>0 || m_i<1000){


soma = x - m_i;

resp += soma;
    }
}
Console.WriteLine(resp+x);
}

}


