﻿using System;

class Program
{
    static void Main()
    {

        string[] valores;
        string linha;

        int t = 0, troca = 0, a = 0, b = 0, c = 0; ;

        t = int.Parse(Console.ReadLine());

        for (int i = 0; i < t; i++)
        {

            linha = Console.ReadLine();
            valores = linha.Split(' ');
            a = int.Parse(valores[0]);
            b = int.Parse(valores[1]);
            c = int.Parse(valores[2]);
            if (a < b && b > c)
            {

                troca = a;

                a = b;

                b = troca;



            }
            else if (a < c && c > b)
            {
                troca = a;

                a = c;

                c = troca;



            }


            if (a <= 0 || b <= 0 || c <= 0)
            {

                Console.WriteLine("n");

            }

            else if (a + b > c && a + c > b && b + c > a)
            {

                if (a * a == b * b + c * c)
                {

                    Console.WriteLine("r");

                }

                else if (a * a > b * b + c * c)
                {

                    Console.WriteLine("o");

                }

                else if (a * a < b * b + c * c)
                {

                    Console.WriteLine("a");

                }

            }

            else
            {
                Console.WriteLine("n");
            }




        }



    }


}