﻿using System;

class Program
{
    static void Main()
    {

        string[] valores;
        string linha;
        int n = 0, m = 0, num = 0, indice = 0, posicao = 0;
        linha = Console.ReadLine();
        valores = linha.Split(' ');

        n = int.Parse(valores[0]);

        m = int.Parse(valores[1]);

        int[] array = new int[n + 1];

        for (int i = 1; i <= m; i++)
        {

            linha = Console.ReadLine();
            valores = linha.Split(' ');
            indice = int.Parse(valores[0]);

            if (indice == 1)
            {

                posicao = int.Parse(valores[1]);
                num = int.Parse(valores[2]);

                for (int f = posicao; f <= array.Length; f++)
                {

                    while (num > 0)
                    {
                        if (array[posicao] == 0)
                        {
                            array[posicao] = num;

                            posicao++;
                            num--;
                        }
                        else
                        {
                            array[posicao] += num;


                            posicao++;
                            num--;


                        }
                    }





                }
            }

            else if (indice == 2)
            {

                posicao = int.Parse(valores[1]);
                num = int.Parse(valores[2]);


                for (int f = posicao; f <= array.Length; f++)
                {

                    while (num > 0 && posicao > 0)
                    {
                        if (array[posicao] == 0)
                        {
                            array[posicao] = num;

                            posicao--;
                            num--;
                        }
                        else
                        {
                            array[posicao] += num;


                            posicao--;
                            num--;


                        }

                    }
                }



            }




            else if (indice == 3)
            {

                posicao = int.Parse(valores[1]);

                Console.WriteLine(array[posicao]);





            }
        }
        /*for (int a = 1; a <= array.Length; a++)
        {
            Console.Write(array[a]);
        }*/
    }
}